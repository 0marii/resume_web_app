package Controller;
import Models.Application;
import Models.User;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

@WebServlet("/apply")
@MultipartConfig
public class ApplicationController extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get form data
        String motivation = request.getParameter("motivation");
        Part filePart = request.getPart("resume");
        InputStream resume = filePart.getInputStream();

        // Get user from session
        HttpSession session = request.getSession();
        User applicant = (User) session.getAttribute("user");

        // Create application
        Application application = new Application();
        application.setApplicant(applicant);
        application.setMotivation(motivation);
        application.setResume(resume);
        application.setStatus("Application Logged");

        // Save to database
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "admin");
            String sql = "INSERT INTO JobApplications (ApplicationID, ApplicantID, Motivation, Resume, Status) VALUES (?,?,?,?,?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, application.getId());
            statement.setInt(2, application.getApplicant().getId());
            statement.setString(3, application.getMotivation());
            statement.setBlob(4, application.getResume());
            statement.setString(5, application.getStatus());
            statement.executeUpdate();

            // Set the Application object in the session
            session.setAttribute("application", application);

            // Redirect to confirmation page
            response.sendRedirect("jobApplication.jsp");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            // Handle the exception as needed
            response.sendRedirect("errorPage.jsp"); // Redirect to an error page if there is an issue
        }
    }
}

