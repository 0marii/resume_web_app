package Controller;

import Models.JobOffer;
import Models.Application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/createJobOffer")
public class OfferController extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Get parameters from request
            int applicationId = Integer.parseInt(request.getParameter("applicationId"));
            String details = request.getParameter("details");
            boolean approved = request.getParameter("approved").equals("Y");

            // Validate the parameters
            if (details == null || details.isEmpty()) {
                // Details are empty
                request.setAttribute("errorMessage", "Details are required.");
                request.getRequestDispatcher("createJobOffer.jsp").forward(request, response);
                return;
            }

            // Create a new JobOffer object
            JobOffer jobOffer = new JobOffer();
            Application application = new Application();
            application.setId(applicationId);
            jobOffer.setApplication(application);
            jobOffer.setDetails(details);
            jobOffer.setApproved(approved);

            // Save the job offer to the database
            try (Connection c = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "admin")) {
                PreparedStatement ps = c.prepareStatement("INSERT INTO JobOffers (ApplicationID, Details, Approved) VALUES (?, ?, ?)");
                ps.setInt(1, jobOffer.getApplication().getId());
                ps.setString(2, jobOffer.getDetails());
                ps.setString(3, jobOffer.isApproved() ? "Y" : "N");
                ps.execute();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Redirect to a success page
        // response.sendRedirect("offerCreated.jsp");
    }
}
