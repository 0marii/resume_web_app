package Controller;

import Models.JobPosting;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/createJobPosting")
public class JobPostingController extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Get parameters from request
            String title = request.getParameter("title");
            Date closingDate = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("closingDate"));
            String details = request.getParameter("details");

            // Validate the parameters
            if (title == null || title.isEmpty() ||
                closingDate == null ||
                details == null || details.isEmpty()) {
                // One or more fields are empty
                request.setAttribute("errorMessage", "All fields are required.");
                request.getRequestDispatcher("createJobPosting.jsp").forward(request, response);
                return;
            }

            // Create a new JobPosting object
            JobPosting jobPosting = new JobPosting();
            jobPosting.setTitle(title);
            jobPosting.setClosingDate(closingDate);
            jobPosting.setDetails(details);

            // Save the job posting to the database
            try {
                Class.forName("oracle.jdbc.OracleDriver");
                try (Connection c = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "admin")) {
                    try (PreparedStatement ps = c.prepareStatement("INSERT INTO JobPostings (Title, ClosingDate, Details) VALUES (?, ?, ?)")) {
                        ps.setString(1, jobPosting.getTitle());
                        ps.setDate(2, new java.sql.Date(jobPosting.getClosingDate().getTime()));
                        ps.setString(3, jobPosting.getDetails());
                        ps.execute();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            // Redirect to a success page
            response.sendRedirect("mainAdmin.jsp");
        } catch (ParseException ex) {
            Logger.getLogger(JobPostingController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
