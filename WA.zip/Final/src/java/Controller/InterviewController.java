package Controller;

import Models.Interview;
import Models.Application;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/createInterview")
public class InterviewController extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get parameters from request
        int applicationId = Integer.parseInt(request.getParameter("applicationId"));
        String notes = request.getParameter("notes");
        boolean approved = request.getParameter("approved").equals("Y");

        // Validate the parameters
        if (notes == null || notes.isEmpty()) {
            // Notes are empty
            request.setAttribute("errorMessage", "Notes are required.");
            request.getRequestDispatcher("createInterview.jsp").forward(request, response);
            return;
        }

        try {
            // Establish database connection
            Class.forName("oracle.jdbc.OracleDriver");
            try (Connection c = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "admin")) {
                // Insert interview data into the database
                String sql = "INSERT INTO Interviews (InterviewID, ApplicationID, Notes, Approved) VALUES (?, ?, ?, ?)";
                try (PreparedStatement ps = c.prepareStatement(sql)) {
                    ps.setInt(1, getNextInterviewId()); // You may need to implement getNextInterviewId() method
                    ps.setInt(2, applicationId);
                    ps.setString(3, notes);
                    ps.setString(4, approved ? "Y" : "N");
                    ps.executeUpdate();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Redirect to a success page
        response.sendRedirect("interviewCreated.jsp");
    }

    private int getNextInterviewId() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
