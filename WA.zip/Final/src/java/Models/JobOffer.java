package Models;

public class JobOffer {

    
    private int id;
    private Application application;
    private String details;
    private boolean approved;
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Application getApplication() {
        return application;
    }

    public void setApplication(Application application) {
        this.application = application;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }
    

    // Constructors
    public JobOffer() {
        // Default constructor
    }

    public JobOffer(Application application, String details, boolean approved) {
        this.application = application;
        this.details = details;
        this.approved = approved;
    }

   
}
