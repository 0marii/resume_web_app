package Models;
import Models.User;
import java.util.Date;

public class Job {
    private int id;
    private String title; // position (ex. Software Engineer)
    private Date closingDate; // deadline for applying
    private String details;
    private User hiringManager;

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getClosingDate() {
        return closingDate;
    }

    public void setClosingDate(Date closingDate) {
        this.closingDate = closingDate;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public User getHiringManager() {
        return hiringManager;
    }

    public void setHiringManager(User hiringManager) {
        this.hiringManager = hiringManager;
    }
}
