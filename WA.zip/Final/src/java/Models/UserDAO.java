package Models;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

    public static void saveUser(User user) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Load the Oracle JDBC driver
            Class.forName("oracle.jdbc.OracleDriver");

            // Establish a connection to the Oracle database
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "admin");

            // Prepare the SQL statement
            preparedStatement = connection.prepareStatement("INSERT INTO JobApplicants (FirstName, LastName, Email, Phone, Address, City, Country, EducationLevel) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            preparedStatement.setString(1, user.getFirstName());
            preparedStatement.setString(2, user.getLastName());
            preparedStatement.setString(3, user.getEmail());
            preparedStatement.setString(4, user.getPhone());
            preparedStatement.setString(5, user.getAddress());
            preparedStatement.setString(6, user.getCity());
            preparedStatement.setString(7, user.getCountry());
            preparedStatement.setString(8, user.getEducationLevel());

            // Execute the SQL statement
            preparedStatement.execute();

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace(); // Handle the exception appropriately

        } finally {
            // Close the resources in a finally block to ensure they are closed
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace(); // Handle the exception appropriately
            }
        }
    }

    public static List<User> getAllUsers() {
        List<User> userList = new ArrayList<>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Load the Oracle JDBC driver
            Class.forName("oracle.jdbc.OracleDriver");

            // Establish a connection to the Oracle database
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "admin");

            // Prepare the SQL statement to retrieve all users
            String sql = "SELECT * FROM JobApplicants";
            preparedStatement = connection.prepareStatement(sql);

            // Execute the SQL query
            resultSet = preparedStatement.executeQuery();

            // Process the result set and populate the User objects
            while (resultSet.next()) {
                User user = new User();
                user.setId(resultSet.getInt("ID"));
                user.setFirstName(resultSet.getString("FirstName"));
                user.setLastName(resultSet.getString("LastName"));
                user.setEmail(resultSet.getString("Email"));
                user.setPhone(resultSet.getString("Phone"));
                user.setAddress(resultSet.getString("Address"));
                user.setCity(resultSet.getString("City"));
                user.setCountry(resultSet.getString("Country"));
                user.setEducationLevel(resultSet.getString("EducationLevel"));
                userList.add(user);
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace(); // Handle the exception appropriately
        } finally {
            // Close the resources in a finally block to ensure they are closed
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace(); // Handle the exception appropriately
            }
        }

        return userList;
    }
}
